﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerInput : MonoBehaviour {

    float inputVertical;
    float inputHorizontal;
    string inputAction;

	
	void Update ()
    {
        ResetInputValues();
        inputVertical = Input.GetAxis("Vertical");
        if (Input.GetMouseButton(2)) { inputVertical = 1.0f; }
        inputHorizontal = Input.GetAxis("Horizontal");
        if (Input.GetKeyDown(KeyCode.Space)) { inputAction = "Jump"; }
        if (Input.GetMouseButtonDown(0)) { inputAction = "Jump"; }
        if (Input.GetKeyDown(KeyCode.Return)) { inputAction = "Toss"; }
        if (Input.GetMouseButtonDown(1)) { inputAction = "Toss"; }
    }

    void ResetInputValues()
    {
        //Shared variables for buttons presses need to have values reset. Floats from Horizontal and Vertical "GetAxis" don't. 
        inputAction = "";
    }

    public float GetVerticalInput()
    { return inputVertical; }

    public float GetHorizontalInput()
    { return inputHorizontal; }

    public string GetActionInput()
    { return inputAction; }



}

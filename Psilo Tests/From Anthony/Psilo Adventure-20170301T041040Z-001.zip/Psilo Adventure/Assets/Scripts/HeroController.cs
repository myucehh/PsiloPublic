﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HeroController : MonoBehaviour {

    public float runningSpeed=1f; 
    float forwardmove=0f;
    Animator anim;
    PlayerInput playerInput;

    void Start()
    {
        anim = GetComponent<Animator>();
        playerInput = GetComponent<PlayerInput>();
    }
	
	
	void Update ()
    {
        GetInputs();
        UpdateAnimations();
        MoveHero();    
	}



    void GetInputs()
    {
        forwardmove = playerInput.GetVerticalInput();
    }

    void MoveHero()
    {
        
        if (forwardmove > 0.7)   // <-- initially, the movement started before feet moved.  This value compensates. 
        {
            transform.Translate(Vector3.forward * runningSpeed * Time.deltaTime);
        }
    }

    void UpdateAnimations()
    {
        anim.SetFloat("Running",forwardmove);
    }

}
